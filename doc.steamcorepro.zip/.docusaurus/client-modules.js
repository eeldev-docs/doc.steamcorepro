export default [
  require("C:\\Projects\\docs\\doc.steamcorepro\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Projects\\docs\\doc.steamcorepro\\node_modules\\@docusaurus\\preset-classic\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Projects\\docs\\doc.steamcorepro\\node_modules\\@docusaurus\\preset-classic\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Projects\\docs\\doc.steamcorepro\\src\\css\\custom.css"),
  require("C:\\Projects\\docs\\doc.steamcorepro\\node_modules\\docusaurus-plugin-image-zoom\\lib\\zoom"),
];
