import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/',
    component: ComponentCreator('/', 'fb3'),
    routes: [
      {
        path: '/',
        component: ComponentCreator('/', 'a20'),
        routes: [
          {
            path: '/',
            component: ComponentCreator('/', '43c'),
            routes: [
              {
                path: '/compatibility',
                component: ComponentCreator('/compatibility', '61e'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/additional/additional_logging',
                component: ComponentCreator('/docfiles/additional/additional_logging', '999'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/additional/authenticating_steam_users',
                component: ComponentCreator('/docfiles/additional/authenticating_steam_users', '276'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/additional/configuring_ipnetdriver',
                component: ComponentCreator('/docfiles/additional/configuring_ipnetdriver', '652'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/additional/duration_control',
                component: ComponentCreator('/docfiles/additional/duration_control', '530'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/additional/incompatible_unique_net_id',
                component: ComponentCreator('/docfiles/additional/incompatible_unique_net_id', '12b'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/achievements_and_stats',
                component: ComponentCreator('/docfiles/features/achievements_and_stats', '85b'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/cloud_saves',
                component: ComponentCreator('/docfiles/features/cloud_saves', 'c9d'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/inventory',
                component: ComponentCreator('/docfiles/features/inventory', 'eea'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/leaderboards',
                component: ComponentCreator('/docfiles/features/leaderboards', 'd7a'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/rich_presence',
                component: ComponentCreator('/docfiles/features/rich_presence', '713'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/steam_input',
                component: ComponentCreator('/docfiles/features/steam_input', '885'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/timeline',
                component: ComponentCreator('/docfiles/features/timeline', 'b0c'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/features/workshop',
                component: ComponentCreator('/docfiles/features/workshop', '7d5'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/game-session/maxplayers',
                component: ComponentCreator('/docfiles/game-session/maxplayers', '37c'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/getting_started/configuring-plugin',
                component: ComponentCreator('/docfiles/getting_started/configuring-plugin', 'cf5'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/getting_started/installing-plugin',
                component: ComponentCreator('/docfiles/getting_started/installing-plugin', 'de4'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/getting_started/package-project',
                component: ComponentCreator('/docfiles/getting_started/package-project', 'e12'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/getting_started/testing_steam_functionality',
                component: ComponentCreator('/docfiles/getting_started/testing_steam_functionality', 'd0c'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/getting_started/using-own-app-id',
                component: ComponentCreator('/docfiles/getting_started/using-own-app-id', 'dcb'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/getting_started/using-plugin',
                component: ComponentCreator('/docfiles/getting_started/using-plugin', '773'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/microtransactions',
                component: ComponentCreator('/docfiles/microtransactions', '520'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/configuring_steamsockets',
                component: ComponentCreator('/docfiles/multiplayer/configuring_steamsockets', '401'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/creating-multiplayer-games',
                component: ComponentCreator('/docfiles/multiplayer/creating-multiplayer-games', 'a45'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers', 'c63'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/connecting',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/connecting', '7b5'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/defaultengine',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/defaultengine', '090'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/filtering_dedicated_servers',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/filtering_dedicated_servers', '51f'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/finding-server',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/finding-server', '147'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/initializing',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/initializing', '3d8'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/introduction',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/introduction', 'e0c'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/leaving-session',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/leaving-session', '6af'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/steamworks',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/steamworks', '8eb'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/dedicated-servers/switching_maps',
                component: ComponentCreator('/docfiles/multiplayer/dedicated-servers/switching_maps', 'b1b'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/finding-multiplayer-games',
                component: ComponentCreator('/docfiles/multiplayer/finding-multiplayer-games', 'c24'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/friends/friends_list',
                component: ComponentCreator('/docfiles/multiplayer/friends/friends_list', 'ebc'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/friends/friends_list_avatars',
                component: ComponentCreator('/docfiles/multiplayer/friends/friends_list_avatars', '3bd'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/friends/inviting_friends',
                component: ComponentCreator('/docfiles/multiplayer/friends/inviting_friends', '536'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/joining-multiplayer-games',
                component: ComponentCreator('/docfiles/multiplayer/joining-multiplayer-games', '1de'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/launching-the-server',
                component: ComponentCreator('/docfiles/multiplayer/launching-the-server', '189'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/lobby_to_game_session',
                component: ComponentCreator('/docfiles/multiplayer/lobby_to_game_session', 'fb6'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/networking_messages',
                component: ComponentCreator('/docfiles/multiplayer/networking_messages', '3ef'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/passworded-session',
                component: ComponentCreator('/docfiles/multiplayer/passworded-session', '303'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/sessions/custom-attributes',
                component: ComponentCreator('/docfiles/multiplayer/sessions/custom-attributes', '798'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/sessions/switching_maps_listen',
                component: ComponentCreator('/docfiles/multiplayer/sessions/switching_maps_listen', '4ce'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/voice-chat/select_microphone',
                component: ComponentCreator('/docfiles/multiplayer/voice-chat/select_microphone', '9a5'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/multiplayer/voice-chat/voice_chat',
                component: ComponentCreator('/docfiles/multiplayer/voice-chat/voice_chat', '0a4'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/parameters',
                component: ComponentCreator('/docfiles/parameters', 'ae6'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/achievements',
                component: ComponentCreator('/docfiles/videos/achievements', '876'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/cloud-save-games',
                component: ComponentCreator('/docfiles/videos/cloud-save-games', '96e'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/dedicated-server-browser',
                component: ComponentCreator('/docfiles/videos/dedicated-server-browser', 'a06'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/dedicated-server-ue5',
                component: ComponentCreator('/docfiles/videos/dedicated-server-ue5', 'e0a'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/friends_list',
                component: ComponentCreator('/docfiles/videos/friends_list', '1c6'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/friends_list_avatars',
                component: ComponentCreator('/docfiles/videos/friends_list_avatars', '336'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/getting_started',
                component: ComponentCreator('/docfiles/videos/getting_started', '544'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/leaderboards',
                component: ComponentCreator('/docfiles/videos/leaderboards', '360'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/multiplayer/configuring-steam-multiplayer',
                component: ComponentCreator('/docfiles/videos/multiplayer/configuring-steam-multiplayer', 'b83'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/multiplayer/creating-joining-multiplayer',
                component: ComponentCreator('/docfiles/videos/multiplayer/creating-joining-multiplayer', '7b8'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/multiplayer/setting-up-steam-multiplayer',
                component: ComponentCreator('/docfiles/videos/multiplayer/setting-up-steam-multiplayer', '8e8'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/docfiles/videos/using-own-appid',
                component: ComponentCreator('/docfiles/videos/using-own-appid', 'bec'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/example-project',
                component: ComponentCreator('/example-project', '687'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/faq',
                component: ComponentCreator('/faq', 'e60'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/purchase-plugin',
                component: ComponentCreator('/purchase-plugin', '2c1'),
                exact: true,
                sidebar: "steamCoreSidebar"
              },
              {
                path: '/',
                component: ComponentCreator('/', '168'),
                exact: true,
                sidebar: "steamCoreSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
